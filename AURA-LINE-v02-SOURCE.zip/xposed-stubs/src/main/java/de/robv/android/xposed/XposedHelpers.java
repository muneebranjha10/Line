package de.robv.android.xposed;
/** Compile-time API signature ONLY. */
public final class XposedHelpers {
    private XposedHelpers() {}
    public static XC_MethodHook.Unhook findAndHookMethod(Class<?> cls, String method, Object... parametersAndCallback) {
        throw new UnsupportedOperationException("compile-only stub");
    }
    public static Class<?> findClassIfExists(String name, ClassLoader loader) {
        throw new UnsupportedOperationException("compile-only stub");
    }
}
