package de.robv.android.xposed;
/** Compile-time API signature ONLY. */
public abstract class XC_MethodHook {
    protected void beforeHookedMethod(MethodHookParam param) throws Throwable { }
    protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
    public static final class Unhook { }
    public static class MethodHookParam {
        public java.lang.reflect.Member method;
        public Object thisObject;
        public Object[] args;
        public void setResult(Object result) { throw new UnsupportedOperationException("compile-only stub"); }
    }
}
