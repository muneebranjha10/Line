package de.robv.android.xposed;
import java.util.Collections;
import java.util.Set;
/** Compile-time API signature ONLY. */
public final class XposedBridge {
    private XposedBridge() {}
    public static void log(String message) { throw new UnsupportedOperationException("compile-only stub"); }
    public static void log(Throwable error) { throw new UnsupportedOperationException("compile-only stub"); }
    public static Set<?> hookAllMethods(Class<?> cls, String methodName, XC_MethodHook callback) {
        throw new UnsupportedOperationException("compile-only stub");
    }
}
