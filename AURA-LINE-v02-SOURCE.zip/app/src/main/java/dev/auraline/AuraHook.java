package dev.auraline;

import android.app.Application;
import android.content.Context;
import android.provider.Settings;
import android.util.Log;
import java.lang.reflect.Method;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Legacy Xposed API entry point, compatible with LSPosed's legacy-module loader. */
public final class AuraHook implements IXposedHookLoadPackage {
    private static final String TAG = "AURA_LINE";
    private static boolean installed;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)
                || !"com.android.systemui".equals(lpparam.processName)) return;
        try {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class,
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam param) {
                            if (installed) return;
                            installed = true;
                            Context ctx = (Context) param.args[0];
                            try {
                                AuraController.getOrCreate(ctx);
                                installControllerHook(lpparam.classLoader);
                                installOptionalStockHook(lpparam.classLoader, ctx);
                                Log.i(TAG, "AURA LINE loaded in SystemUI");
                            } catch (Throwable error) {
                                Log.e(TAG, "Initialization failed; do not replace stock UI", error);
                            }
                        }
                    });
        } catch (Throwable error) {
            XposedBridge.log("AURA LINE: Application.attach hook failed: " + error);
        }
    }

    private static void installControllerHook(ClassLoader loader) {
        Class<?> target = XposedHelpers.findClassIfExists(
                "com.android.systemui.volume.VolumeDialogControllerImpl", loader);
        if (target == null) {
            Log.w(TAG, "Controller class not found (broadcast listener is the fallback)");
            return;
        }
        try {
            XposedBridge.hookAllMethods(target, "onVolumeChangedW", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    if (param.args == null || param.args.length < 1
                            || !(param.args[0] instanceof Integer)) return;
                    AuraController controller = AuraController.get();
                    if (controller != null) controller.onControllerUpdate((Integer) param.args[0]);
                }
            });
            Log.i(TAG, "AOSP controller hook registered");
        } catch (Throwable error) {
            Log.w(TAG, "Controller hook unavailable, continuing with broadcast", error);
        }
    }

    private static void installOptionalStockHook(ClassLoader loader, Context ctx) {
        // IMPORTANT: opt-in only and disabled by default. Samsung OEM class layouts vary.
        // On failure, stock UI stays untouched. Never blanket-hook android.app.Dialog.
        String[] classes = {
                "com.android.systemui.volume.VolumeDialogImpl",
                "com.android.systemui.volume.VolumeDialog"
        };
        for (String name : classes) {
            Class<?> cls = XposedHelpers.findClassIfExists(name, loader);
            if (cls == null) continue;
            for (String methodName : new String[]{"showH", "show"}) {
                try {
                    XposedBridge.hookAllMethods(cls, methodName, new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            if (!(param.method instanceof Method)
                                    || ((Method) param.method).getReturnType() != Void.TYPE) return;
                            if (Settings.Global.getInt(ctx.getContentResolver(),
                                    AuraController.REPLACE_SETTING, 0) != 1) return;
                            AuraController controller = AuraController.get();
                            // Do not cancel the stock panel before the custom window has appeared.
                            if (controller == null || !controller.isAttached()) return;
                            param.setResult(null);
                        }
                    });
                    Log.i(TAG, "Installed optional candidate " + name + '.' + methodName);
                } catch (Throwable ignored) {
                    // The method is absent or blocked on this Samsung build.
                }
            }
        }
    }
}
